"""
Git Hooks and Continuous IP Protection System for Negative Space Imaging Project
"""
import os
import sys
import hashlib
import json
import time
from datetime import datetime
from typing import Dict, List, Any
from pathlib import Path

class IPProtectionHooks:
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.database_path = self.repo_path / "IP_Protection" / "ip_database.json"
        self.load_database()

    def load_database(self):
        """Load or initialize the IP tracking database"""
        if self.database_path.exists():
            with open(self.database_path, 'r') as f:
                self.database = json.load(f)
        else:
            self.database = {
                "files": {},
                "licenses": {},
                "ip_violations": [],
                "last_scan": None
            }
            self.save_database()

    def save_database(self):
        """Save the current state of the IP database"""
        os.makedirs(self.database_path.parent, exist_ok=True)
        with open(self.database_path, 'w') as f:
            json.dump(self.database, f, indent=2)

    def pre_commit_hook(self, files: List[str]) -> bool:
        """Pre-commit hook to check for IP protection headers and sensitive content"""
        for file in files:
            if not self._check_file_headers(file):
                print(f"ERROR: Missing IP protection header in {file}")
                return False
            if self._contains_sensitive_content(file):
                print(f"WARNING: Possible sensitive content in {file}")
                return False
        return True

    def _check_file_headers(self, file_path: str) -> bool:
        """Verify proper IP protection headers exist"""
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read(500)  # Read header portion
            return "Copyright (c) 2025 Negative Space Imaging Project" in content

    def _contains_sensitive_content(self, file_path: str) -> bool:
        """Check for potential sensitive content"""
        sensitive_patterns = [
            "SECRET",
            "PASSWORD",
            "API_KEY",
            "PRIVATE_KEY"
        ]
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            return any(pattern in content.upper() for pattern in sensitive_patterns)

    def monitor_changes(self):
        """Continuous monitoring for file changes"""
        while True:
            self._scan_for_changes()
            time.sleep(300)  # Check every 5 minutes

    def _scan_for_changes(self):
        """Scan repository for changes and potential IP violations"""
        current_state = {}
        for root, _, files in os.walk(self.repo_path):
            for file in files:
                if file.endswith(('.py', '.js', '.ts', '.md')):
                    path = Path(root) / file
                    with open(path, 'rb') as f:
                        content = f.read()
                        current_state[str(path)] = {
                            'hash': hashlib.sha256(content).hexdigest(),
                            'timestamp': datetime.now().isoformat()
                        }
        
        # Compare with previous state
        for file_path, current_info in current_state.items():
            if file_path in self.database['files']:
                if current_info['hash'] != self.database['files'][file_path]['hash']:
                    self._log_file_change(file_path, current_info)
            else:
                self._log_new_file(file_path, current_info)
        
        self.database['files'].update(current_state)
        self.database['last_scan'] = datetime.now().isoformat()
        self.save_database()

    def _log_file_change(self, file_path: str, info: Dict[str, Any]):
        """Log detected file changes"""
        print(f"Change detected in {file_path}")
        # Add to monitoring log
        with open(self.repo_path / "IP_Protection" / "monitoring_log.txt", 'a') as f:
            f.write(f"{info['timestamp']}: Change detected in {file_path}\n")

    def _log_new_file(self, file_path: str, info: Dict[str, Any]):
        """Log new file additions"""
        print(f"New file detected: {file_path}")
        # Add to monitoring log
        with open(self.repo_path / "IP_Protection" / "monitoring_log.txt", 'a') as f:
            f.write(f"{info['timestamp']}: New file added: {file_path}\n")
