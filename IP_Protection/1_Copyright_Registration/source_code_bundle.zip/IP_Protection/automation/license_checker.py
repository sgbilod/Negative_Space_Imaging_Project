"""
License Compliance Checker for IP Protection
"""
import os
import json
from typing import Dict, List, Set
from pathlib import Path

class LicenseComplianceChecker:
    def __init__(self, project_root: str):
        self.project_root = Path(project_root)
        self.compliance_path = self.project_root / "IP_Protection" / "compliance"
        os.makedirs(self.compliance_path, exist_ok=True)
        
        self.known_licenses = {
            'MIT': self._load_license_text('MIT'),
            'Apache-2.0': self._load_license_text('Apache-2.0'),
            'GPL-3.0': self._load_license_text('GPL-3.0')
        }

    def _load_license_text(self, license_name: str) -> str:
        """Load license text from known licenses"""
        license_file = self.compliance_path / f"{license_name}.txt"
        if license_file.exists():
            with open(license_file, 'r') as f:
                return f.read()
        return ""

    def scan_dependencies(self) -> Dict:
        """Scan project dependencies for license compliance"""
        results = {
            'compliant': [],
            'non_compliant': [],
            'unknown': []
        }

        # Check Python dependencies
        if (self.project_root / 'requirements.txt').exists():
            self._check_python_dependencies(results)

        # Check Node.js dependencies
        if (self.project_root / 'package.json').exists():
            self._check_node_dependencies(results)

        # Save compliance report
        report_path = self.compliance_path / 'compliance_report.json'
        with open(report_path, 'w') as f:
            json.dump(results, f, indent=2)

        return results

    def _check_python_dependencies(self, results: Dict):
        """Check Python package dependencies for license compliance"""
        try:
            import pkg_resources
            for dist in pkg_resources.working_set:
                self._check_package_license(dist.key, dist.version, results)
        except Exception as e:
            print(f"Error checking Python dependencies: {str(e)}")

    def _check_node_dependencies(self, results: Dict):
        """Check Node.js package dependencies for license compliance"""
        package_json = self.project_root / 'package.json'
        if package_json.exists():
            try:
                with open(package_json, 'r') as f:
                    data = json.load(f)
                dependencies = {
                    **data.get('dependencies', {}),
                    **data.get('devDependencies', {})
                }
                for package, version in dependencies.items():
                    self._check_package_license(package, version, results)
            except Exception as e:
                print(f"Error checking Node.js dependencies: {str(e)}")

    def _check_package_license(self, package: str, version: str, results: Dict):
        """Check if a package's license is compliant"""
        # This would typically check against a license API or database
        # For now, we'll simulate the check
        license_type = self._get_package_license(package)
        
        if license_type in ['MIT', 'Apache-2.0']:
            results['compliant'].append({
                'package': package,
                'version': version,
                'license': license_type
            })
        elif license_type in ['GPL-3.0']:
            results['non_compliant'].append({
                'package': package,
                'version': version,
                'license': license_type,
                'reason': 'GPL-3.0 may be incompatible with project requirements'
            })
        else:
            results['unknown'].append({
                'package': package,
                'version': version,
                'license': license_type
            })

    def _get_package_license(self, package: str) -> str:
        """Get the license type for a package (mock implementation)"""
        # In a real implementation, this would query package metadata
        # For now, return a mock result
        return "MIT"  # Mock response

    def generate_notice_file(self):
        """Generate a NOTICE file for all used third-party software"""
        notice_content = [
            "THIRD-PARTY SOFTWARE NOTICES AND INFORMATION",
            "----------------------------------------",
            "",
            "This project incorporates components from the following third-party software:",
            ""
        ]

        results = self.scan_dependencies()
        
        for package in results['compliant']:
            notice_content.extend([
                f"Package: {package['package']}",
                f"Version: {package['version']}",
                f"License: {package['license']}",
                ""
            ])

        with open(self.compliance_path / 'NOTICE', 'w') as f:
            f.write('\n'.join(notice_content))
