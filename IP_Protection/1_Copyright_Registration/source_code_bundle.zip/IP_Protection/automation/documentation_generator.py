"""
Automated Documentation Generator for IP Protection
"""
import os
import ast
import json
from typing import Dict, List
from pathlib import Path

class IPDocumentationGenerator:
    def __init__(self, project_root: str):
        self.project_root = Path(project_root)
        self.docs_path = self.project_root / "IP_Protection" / "documentation"
        os.makedirs(self.docs_path, exist_ok=True)

    def generate_documentation(self):
        """Generate comprehensive documentation for IP protection"""
        self._document_source_code()
        self._generate_innovation_report()
        self._create_copyright_manifests()

    def _document_source_code(self):
        """Generate detailed documentation for all source code"""
        for root, _, files in os.walk(self.project_root):
            for file in files:
                if file.endswith('.py'):
                    self._document_python_file(Path(root) / file)

    def _document_python_file(self, file_path: Path):
        """Generate documentation for a Python file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                tree = ast.parse(f.read())
            
            doc_data = {
                'file_path': str(file_path),
                'classes': [],
                'functions': [],
                'innovations': []
            }

            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    doc_data['classes'].append({
                        'name': node.name,
                        'docstring': ast.get_docstring(node),
                        'methods': self._get_class_methods(node)
                    })
                elif isinstance(node, ast.FunctionDef):
                    doc_data['functions'].append({
                        'name': node.name,
                        'docstring': ast.get_docstring(node)
                    })

            # Save documentation
            rel_path = file_path.relative_to(self.project_root)
            doc_file = self.docs_path / f"{rel_path.stem}_documentation.json"
            os.makedirs(doc_file.parent, exist_ok=True)
            with open(doc_file, 'w') as f:
                json.dump(doc_data, f, indent=2)

        except Exception as e:
            print(f"Error documenting {file_path}: {str(e)}")

    def _get_class_methods(self, class_node: ast.ClassDef) -> List[Dict]:
        """Extract method information from a class"""
        methods = []
        for node in ast.walk(class_node):
            if isinstance(node, ast.FunctionDef):
                methods.append({
                    'name': node.name,
                    'docstring': ast.get_docstring(node)
                })
        return methods

    def _generate_innovation_report(self):
        """Generate a report of innovative features"""
        innovations = []
        
        # Scan for innovative features in documentation
        for root, _, files in os.walk(self.docs_path):
            for file in files:
                if file.endswith('_documentation.json'):
                    with open(Path(root) / file, 'r') as f:
                        data = json.load(f)
                        # Look for innovative features in docstrings
                        for cls in data['classes']:
                            if cls['docstring'] and 'novel' in cls['docstring'].lower():
                                innovations.append({
                                    'type': 'class',
                                    'name': cls['name'],
                                    'file': data['file_path'],
                                    'description': cls['docstring']
                                })

        # Save innovation report
        with open(self.docs_path / 'innovation_report.json', 'w') as f:
            json.dump(innovations, f, indent=2)

    def _create_copyright_manifests(self):
        """Create manifests for copyright registration"""
        manifest = {
            'source_files': [],
            'documentation_files': [],
            'assets': []
        }

        # Collect all source files
        for root, _, files in os.walk(self.project_root):
            for file in files:
                path = Path(root) / file
                if file.endswith(('.py', '.js', '.ts')):
                    manifest['source_files'].append(str(path))
                elif file.endswith(('.md', '.txt', '.rst')):
                    manifest['documentation_files'].append(str(path))
                elif file.endswith(('.png', '.jpg', '.svg')):
                    manifest['assets'].append(str(path))

        # Save copyright manifest
        with open(self.docs_path / 'copyright_manifest.json', 'w') as f:
            json.dump(manifest, f, indent=2)
