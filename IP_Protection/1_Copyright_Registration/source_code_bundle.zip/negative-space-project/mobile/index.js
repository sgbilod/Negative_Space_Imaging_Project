import React from 'react';
import { AppRegistry } from 'react-native';
import { NotaryARApp } from '../revenue/decentralized_notary/mobile_client';

AppRegistry.registerComponent('NotaryARApp', () => NotaryARApp);
